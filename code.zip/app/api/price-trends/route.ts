import { NextResponse } from "next/server"

// Mock data for global production trends
// This represents prices for different raw materials over time
const priceData = [
  // Gas Bumi (Natural Gas)
  { date: "2020-01", material: "Gas Bumi", price: 45 },
  { date: "2020-06", material: "Gas Bumi", price: 42 },
  { date: "2021-01", material: "Gas Bumi", price: 48 },
  { date: "2021-06", material: "Gas Bumi", price: 55 },
  { date: "2022-01", material: "Gas Bumi", price: 62 },
  { date: "2022-06", material: "Gas Bumi", price: 75 },
  { date: "2023-01", material: "Gas Bumi", price: 68 },
  { date: "2023-06", material: "Gas Bumi", price: 58 },
  { date: "2024-01", material: "Gas Bumi", price: 52 },
  { date: "2024-06", material: "Gas Bumi", price: 48 },
  { date: "2024-11", material: "Gas Bumi", price: 50 },

  // Nitrogen Liquid
  { date: "2020-01", material: "Nitrogen Liquid", price: 120 },
  { date: "2020-06", material: "Nitrogen Liquid", price: 125 },
  { date: "2021-01", material: "Nitrogen Liquid", price: 135 },
  { date: "2021-06", material: "Nitrogen Liquid", price: 148 },
  { date: "2022-01", material: "Nitrogen Liquid", price: 165 },
  { date: "2022-06", material: "Nitrogen Liquid", price: 185 },
  { date: "2023-01", material: "Nitrogen Liquid", price: 175 },
  { date: "2023-06", material: "Nitrogen Liquid", price: 158 },
  { date: "2024-01", material: "Nitrogen Liquid", price: 142 },
  { date: "2024-06", material: "Nitrogen Liquid", price: 138 },
  { date: "2024-11", material: "Nitrogen Liquid", price: 140 },

  // Sulphuric Acid
  { date: "2020-01", material: "Sulphuric Acid", price: 85 },
  { date: "2020-06", material: "Sulphuric Acid", price: 88 },
  { date: "2021-01", material: "Sulphuric Acid", price: 95 },
  { date: "2021-06", material: "Sulphuric Acid", price: 105 },
  { date: "2022-01", material: "Sulphuric Acid", price: 125 },
  { date: "2022-06", material: "Sulphuric Acid", price: 145 },
  { date: "2023-01", material: "Sulphuric Acid", price: 135 },
  { date: "2023-06", material: "Sulphuric Acid", price: 120 },
  { date: "2024-01", material: "Sulphuric Acid", price: 108 },
  { date: "2024-06", material: "Sulphuric Acid", price: 102 },
  { date: "2024-11", material: "Sulphuric Acid", price: 105 },

  // Phosphate Rock
  { date: "2020-01", material: "Phosphate Rock", price: 95 },
  { date: "2020-06", material: "Phosphate Rock", price: 98 },
  { date: "2021-01", material: "Phosphate Rock", price: 108 },
  { date: "2021-06", material: "Phosphate Rock", price: 122 },
  { date: "2022-01", material: "Phosphate Rock", price: 142 },
  { date: "2022-06", material: "Phosphate Rock", price: 165 },
  { date: "2023-01", material: "Phosphate Rock", price: 152 },
  { date: "2023-06", material: "Phosphate Rock", price: 135 },
  { date: "2024-01", material: "Phosphate Rock", price: 118 },
  { date: "2024-06", material: "Phosphate Rock", price: 112 },
  { date: "2024-11", material: "Phosphate Rock", price: 115 },

  // Potassium Chloride (KCl)
  { date: "2020-01", material: "KCl", price: 110 },
  { date: "2020-06", material: "KCl", price: 115 },
  { date: "2021-01", material: "KCl", price: 128 },
  { date: "2021-06", material: "KCl", price: 145 },
  { date: "2022-01", material: "KCl", price: 168 },
  { date: "2022-06", material: "KCl", price: 192 },
  { date: "2023-01", material: "KCl", price: 178 },
  { date: "2023-06", material: "KCl", price: 158 },
  { date: "2024-01", material: "KCl", price: 138 },
  { date: "2024-06", material: "KCl", price: 132 },
  { date: "2024-11", material: "KCl", price: 135 },
]

export async function GET() {
  try {
    // Get unique materials
    const materials = [...new Set(priceData.map((d) => d.material))]

    // Get date range
    const dates = [...new Set(priceData.map((d) => d.date))].sort()

    return NextResponse.json({
      data: priceData,
      materials,
      dateRange: {
        start: dates[0],
        end: dates[dates.length - 1],
      },
    })
  } catch (error) {
    console.error("Error fetching price trends:", error)
    return NextResponse.json({ error: "Failed to fetch price trends" }, { status: 500 })
  }
}
